# Schoolcoding
This is all my code form 6th year at St Benildus College. 
I know most of it is very simple.
