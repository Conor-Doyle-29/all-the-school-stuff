for num in range(1,5,1):
    print("loop",num)