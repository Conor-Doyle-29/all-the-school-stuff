num = 1 
nums=[num]

for i in range(1,1000):
    num+=1
    nums.append(num)
   
print(nums)  